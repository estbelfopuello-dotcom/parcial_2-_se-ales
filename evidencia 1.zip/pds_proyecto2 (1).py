#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDS Teoría - Proyecto 2 (2026-2): mejora de la SNR de una IMU con filtros FIR e IIR
===================================================================================

Modos de uso:

  1) PRUEBA DEL MOTOR (sin tomar datos; sirve para verificar el hardware):
        python pds_proyecto2.py motor --puerto COM5 --pwm 100 --segundos 5

  2) CAPTURA desde el ESP32 (firmware: esp32_adquisicion.ino). Guarda R1, R2 y R3:
        python pds_proyecto2.py capturar --puerto COM5 --pwm-bajo 30 --pwm-alto 80

  3) ANÁLISIS offline (sólo lee los CSV crudos; no necesita el ESP32):
        python pds_proyecto2.py analizar --carpeta datos
        python pds_proyecto2.py analizar --carpeta datos --fc 3      # otro corte (para N5)

Otros:
        python pds_proyecto2.py puertos                               # lista los puertos serie

Dependencias:  pip install numpy scipy pandas matplotlib pyserial

Modelo (enunciado):  x[n] = s[n] + v[n]
    P_s = media(x)^2          P_n = media((x - media(x))^2)
    SNR = 10 log10(P_s / P_n)   [dB]          dSNR = SNR_salida - SNR_entrada
Filtros (diseño igual al del notebook del profesor: firwin, butter, lfilter, freqz, roots):
    FIR por ventana (Hamming), orden 20 (21 coeficientes), fc = 5 Hz
    IIR Butterworth pasa-bajas, orden 2, fc = 5 Hz
Ambos se aplican con lfilter (causal) sobre exactamente los mismos datos y se descarta
el primer segundo de cada salida antes de calcular la SNR de salida.
"""
import argparse
import sys
import time
import warnings
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import firwin, butter, lfilter, freqz, group_delay, tf2zpk, welch

# ----------------------------- Parámetros del enunciado -----------------------------
BAUDIOS = 115200
DURACION_S = 20
FC_HZ = 5.0            # frecuencia de corte común a ambos filtros
ORDEN_FIR = 20         # numtaps = orden + 1 (como indica el notebook)
ORDEN_IIR = 2
DESCARTE_S = 1.0       # transitorio inicial que se elimina de cada salida
REGISTROS = ["R1", "R2", "R3"]
DESCRIPCION = {"R1": "motor apagado", "R2": "perturbación baja", "R3": "perturbación alta"}
EJES = {"x": 0, "y": 1, "z": 2}
# La SNR de entrada se calcula sobre el registro completo (CSV crudo). Si el docente pide
# compararla sobre el mismo tramo que las salidas, ponerlo en True.
ENTRADA_RECORTADA = False


# =====================================================================================
#  CAPTURA (ESP32 por puerto serie)
# =====================================================================================
def cmd_puertos(_args):
    from serial.tools import list_ports
    puertos = list(list_ports.comports())
    if not puertos:
        print("No se encontraron puertos serie.")
    for p in puertos:
        print(f"{p.device}\t{p.description}")


def abrir_puerto(puerto):
    import serial
    from serial.tools import list_ports
    if puerto is None:
        disponibles = [p.device for p in list_ports.comports()]
        if not disponibles:
            sys.exit("No hay puertos serie disponibles. Conecta el ESP32 o usa --puerto.")
        puerto = disponibles[0]
        print(f"Puerto no indicado: usando {puerto} (disponibles: {disponibles})")
    ser = serial.Serial(puerto, BAUDIOS, timeout=1)
    time.sleep(2.0)                      # el ESP32 se reinicia al abrir el puerto
    ser.reset_input_buffer()
    for _ in range(5):
        ser.write(b"PING\n")
        t_fin = time.time() + 1.5
        while time.time() < t_fin:
            linea = ser.readline().decode(errors="ignore").strip()
            if linea.startswith("OK"):
                print(f"ESP32 conectado en {puerto}: {linea}")
                return ser
    ser.close()
    sys.exit("El ESP32 no responde al PING. Revisa el puerto, el baudrate (115200) y que "
             "esté cargado el firmware esp32_adquisicion.ino.")


def cmd_motor(args):
    """Prueba directa del motor: lo enciende al PWM indicado, espera y lo apaga."""
    ser = abrir_puerto(args.puerto)
    try:
        pwm = max(0, min(100, args.pwm))
        ser.write(f"MOTOR {pwm}\n".encode())
        t_fin = time.time() + 2.0
        while time.time() < t_fin:
            linea = ser.readline().decode(errors="ignore").strip()
            if linea:
                print(f"ESP32: {linea}")
                if linea.startswith("OK") or linea.startswith("ERR"):
                    break
        print(f"Motor al {pwm} % durante {args.segundos:g} s ...")
        time.sleep(args.segundos)
    finally:
        ser.write(b"STOP\n")
        time.sleep(0.2)
        print("ESP32:", ser.readline().decode(errors="ignore").strip() or "(sin respuesta)")
        ser.close()
    print("Motor detenido.")


def capturar_registro(ser, nombre, pwm):
    """Pide un registro al ESP32 y devuelve (meta, datos[N,4] = t_us, ax, ay, az)."""
    ser.reset_input_buffer()
    ser.write(f"START {nombre} {pwm}\n".encode())
    meta, filas, malas, terminado = {}, [], 0, False
    limite = time.time() + DURACION_S + 40       # captura + warm-up + envío
    while time.time() < limite:
        linea = ser.readline().decode(errors="ignore").strip()
        if not linea:
            continue
        if linea.startswith("#"):
            clave, _, valor = linea[1:].partition("=")
            meta[clave.strip()] = valor.strip()
        elif linea.startswith("D,"):
            try:
                _, t, ax, ay, az = linea.split(",")
                filas.append((int(t), int(ax), int(ay), int(az)))
            except ValueError:
                malas += 1
        elif linea.startswith("ERR"):
            raise RuntimeError(f"el ESP32 reportó: {linea}")
        elif linea == "END":
            terminado = True
            break
    if not terminado:
        raise RuntimeError("tiempo agotado esperando el final del registro (END)")
    n_esperado = int(meta.get("n", len(filas)))
    if malas or len(filas) != n_esperado:
        raise RuntimeError(f"datos incompletos: {len(filas)}/{n_esperado} muestras, {malas} líneas dañadas")
    return meta, np.array(filas, dtype=np.int64)


def elegir_eje(datos):
    medias = np.abs(datos[:, 1:4].mean(axis=0))
    return "xyz"[int(np.argmax(medias))]


def guardar_registro(carpeta, nombre, pwm, meta, datos, eje, puerto):
    lsb_g = float(meta.get("lsb_por_g", 16384))
    t = (datos[:, 0] - datos[0, 0]) / 1e6
    raw = datos[:, 1 + EJES[eje]]
    dt = np.diff(t)
    fs_obs = 1.0 / np.median(dt)

    cabecera = [
        f"registro={nombre} ({DESCRIPCION[nombre]})",
        f"fecha={datetime.now().isoformat(timespec='seconds')}",
        f"imu={meta.get('imu', 'MPU6050/6500')}  who_am_i={meta.get('who_am_i', '?')}",
        f"eje_seleccionado={eje}  rango=+-{meta.get('rango_g', '2')} g  lsb_por_g={lsb_g:g}",
        f"fs_nominal_hz={meta.get('fs_hz', '100')}  fs_observada_hz={fs_obs:.3f}  jitter_dt_ms={dt.std() * 1e3:.3f}",
        f"pwm_motor_pct={pwm}  errores_i2c={meta.get('i2c_errores', '0')}",
        "unidades: timestamp_s [s] | raw_lsb [cuentas del ADC, dato crudo] | accel_g [g = raw_lsb/lsb_por_g]",
    ]
    ruta = carpeta / f"{nombre}.csv"
    with open(ruta, "w", encoding="utf-8", newline="\n") as f:
        f.write("".join(f"# {c}\n" for c in cabecera))
        pd.DataFrame({"timestamp_s": t, "raw_lsb": raw, "accel_g": raw / lsb_g}).to_csv(
            f, index=False, float_format="%.6f")

    # Extra (para N5: segundo eje). No se usa en el cálculo obligatorio.
    pd.DataFrame({"timestamp_s": t, "ax_raw": datos[:, 1], "ay_raw": datos[:, 2],
                  "az_raw": datos[:, 3]}).to_csv(carpeta / f"{nombre}_3ejes.csv", index=False,
                                                 float_format="%.6f")
    print(f"  -> {ruta.name}: {len(t)} muestras, fs observada {fs_obs:.2f} Hz, "
          f"jitter {dt.std() * 1e3:.2f} ms, media eje {eje} = {raw.mean() / lsb_g:+.4f} g, "
          f"errores I2C = {meta.get('i2c_errores', '0')}")
    return ruta


def cmd_capturar(args):
    carpeta = Path(args.carpeta)
    carpeta.mkdir(parents=True, exist_ok=True)
    plan = {"R1": 0, "R2": args.pwm_bajo, "R3": args.pwm_alto}
    elegidos = args.solo or REGISTROS
    eje = args.eje
    if eje == "auto" and "R1" not in elegidos:
        sys.exit("Si no capturas R1, indica el eje con --eje x|y|z (debe ser el mismo en R1-R3).")

    ser = abrir_puerto(args.puerto)
    try:
        for nombre in elegidos:
            pwm = plan[nombre]
            input(f"\n[{nombre}] {DESCRIPCION[nombre]} (PWM {pwm} %). IMU fija y sin tocar. "
                  f"Enter para iniciar ({DURACION_S} s)... ")
            for intento in range(1, 4):
                try:
                    print("  capturando...")
                    meta, datos = capturar_registro(ser, nombre, pwm)
                    break
                except RuntimeError as e:
                    print(f"  ! Intento {intento}/3 falló: {e}")
            else:
                sys.exit(f"No se pudo capturar {nombre}.")
            if eje == "auto":
                eje = elegir_eje(datos)
                print(f"  Eje alineado con la gravedad (mayor |media|): {eje}  -> se usará en R1-R3")
            guardar_registro(carpeta, nombre, pwm, meta, datos, eje, args.puerto)
    finally:
        ser.write(b"STOP\n")             # apaga el motor pase lo que pase
        ser.close()
    print(f"\nListo. CSV en {carpeta.resolve()}  ->  python {Path(sys.argv[0]).name} analizar --carpeta {carpeta}")


# =====================================================================================
#  ANÁLISIS (FIR / IIR / SNR)
# =====================================================================================
def potencias(x):
    """P_s = media(x)^2 (señal útil = gravedad);  P_n = media((x-media(x))^2) (ruido)."""
    m = np.mean(x)
    return m ** 2, np.mean((x - m) ** 2)


def snr_db(x):
    ps, pn = potencias(x)
    return 10.0 * np.log10(ps / pn)


def leer_registro(ruta):
    df = pd.read_csv(ruta, comment="#")
    t = df["timestamp_s"].to_numpy(float)
    x = df["accel_g"].to_numpy(float)       # g = raw/lsb_por_g (escala lineal: no cambia la SNR)
    dt = np.diff(t)
    return {"t": t, "x": x, "fs": 1.0 / np.median(dt), "jitter_ms": dt.std() * 1e3}


def disenar_filtros(fs, fc, orden_fir, orden_iir):
    h = firwin(orden_fir + 1, fc, fs=fs, window="hamming")      # FIR por ventana
    b, a = butter(orden_iir, fc, btype="low", fs=fs)            # IIR Butterworth
    return h, b, a


def tiempo_ejecucion_us(num, den, x, repeticiones=300):
    lfilter(num, den, x)                                        # calentamiento
    ts = []
    for _ in range(repeticiones):
        t0 = time.perf_counter()
        lfilter(num, den, x)
        ts.append(time.perf_counter() - t0)
    return float(np.median(ts) * 1e6)


def retardo_observado_muestras(num, den, n=2000):
    """Rampa sintética: en régimen y[n] = x[n - d]  ->  d = retardo (muestras)."""
    rampa = np.arange(n, dtype=float)
    y = lfilter(num, den, rampa)
    return float(np.mean(rampa[n // 2:] - y[n // 2:]))


def retardo_teorico_muestras(num, den, fs, fc):
    """Retardo de grupo a muy baja frecuencia (~DC), donde está la gravedad."""
    w = 2 * np.pi * np.array([0.05]) / fs
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        _, gd = group_delay((num, den), w=w)
    return float(gd[0])


def estabilidad(den):
    polos = np.roots(den)                                        # como en el notebook
    pmax = float(np.max(np.abs(polos))) if polos.size else 0.0
    return pmax < 1.0, pmax


def procesar_registro(nombre, d, h, b, a, fs, n0):
    x = d["x"]
    yf = lfilter(h, [1.0], x)
    yi = lfilter(b, a, x)
    xs, yfs, yis = x[n0:], yf[n0:], yi[n0:]
    x_ent = xs if ENTRADA_RECORTADA else x

    ps, pn = potencias(x_ent)
    snr_in, snr_f, snr_i = snr_db(x_ent), snr_db(yfs), snr_db(yis)
    m_in = float(np.mean(x_ent))
    fila_snr = {
        "registro": nombre, "media_in_g": m_in, "Ps": ps, "Pn": pn,
        "SNR_in_dB": snr_in,
        "SNR_FIR_dB": snr_f, "dSNR_FIR_dB": snr_f - snr_in,
        "SNR_IIR_dB": snr_i, "dSNR_IIR_dB": snr_i - snr_in,
        "dMedia_FIR_g": float(np.mean(yfs)) - m_in,
        "dMedia_FIR_%": 100 * (float(np.mean(yfs)) - m_in) / abs(m_in),
        "dMedia_IIR_g": float(np.mean(yis)) - m_in,
        "dMedia_IIR_%": 100 * (float(np.mean(yis)) - m_in) / abs(m_in),
    }
    return fila_snr, yf, yi


# --------------------------------- Figuras -----------------------------------------
def fig_respuesta(h, b, a, fs, fc, ruta):
    w, Hf = freqz(h, [1.0], worN=2048, fs=fs)
    _, Hi = freqz(b, a, worN=2048, fs=fs)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        _, gf = group_delay((h, [1.0]), w=2048, fs=fs)
        _, gi = group_delay((b, a), w=2048, fs=fs)
    fig, ax = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    ax[0].plot(w, 20 * np.log10(np.abs(Hf) + 1e-12), label=f"FIR orden {len(h) - 1}")
    ax[0].plot(w, 20 * np.log10(np.abs(Hi) + 1e-12), label=f"IIR Butterworth orden {len(a) - 1}")
    ax[0].axvline(fc, color="k", ls="--", lw=0.8, label=f"fc = {fc:g} Hz")
    ax[0].axhline(-3, color="gray", ls=":", lw=0.8)
    ax[0].set_ylim(-90, 5)
    ax[0].set_ylabel("Magnitud [dB]")
    ax[0].set_title("Respuesta en frecuencia")
    ax[0].legend()
    ax[0].grid(True)
    ax[1].plot(w, gf, label="FIR (fase lineal: retardo constante)")
    ax[1].plot(w, gi, label="IIR (retardo variable con la frecuencia)")
    ax[1].axvline(fc, color="k", ls="--", lw=0.8)
    ax[1].set_xlabel("Frecuencia [Hz]")
    ax[1].set_ylabel("Retardo de grupo [muestras]")
    ax[1].set_ylim(0, max(15, float(np.nanmax(gf)) * 1.3))
    ax[1].legend()
    ax[1].grid(True)
    fig.tight_layout()
    fig.savefig(ruta, dpi=150)
    return fig


def fig_polos_ceros(h, b, a, ruta):
    zf = np.roots(np.where(np.abs(h) < 1e-12, 0.0, h))      # ceros del FIR (h[0], h[20] ~ 0 con fc=5 Hz, fs=100 Hz)
    zi, pi_, _ = tf2zpk(b, a)
    fig, ax = plt.subplots(1, 2, figsize=(11, 5))
    for k, (z, p, titulo, nota) in enumerate([
            (zf, np.array([]), f"FIR orden {len(h) - 1}", f"{len(h) - 1} polos en z = 0"),
            (zi, pi_, f"IIR Butterworth orden {len(a) - 1}", "")]):
        ax[k].add_patch(plt.Circle((0, 0), 1, fill=False, color="gray"))
        ax[k].plot(z.real, z.imag, "o", mfc="none", ms=8, label="ceros")
        if p.size:
            ax[k].plot(p.real, p.imag, "x", ms=9, color="red", label="polos")
        ax[k].axhline(0, color="k", lw=0.5)
        ax[k].axvline(0, color="k", lw=0.5)
        ax[k].set_aspect("equal")
        ax[k].set_xlim(-1.6, 1.6)
        ax[k].set_ylim(-1.6, 1.6)
        ax[k].set_title(titulo + (f"  ({nota})" if nota else ""))
        ax[k].set_xlabel("Re(z)")
        ax[k].set_ylabel("Im(z)")
        ax[k].legend(loc="upper left")
        ax[k].grid(True)
    fig.tight_layout()
    fig.savefig(ruta, dpi=150)
    return fig


def fig_registro(nombre, t, x, yf, yi, n0, fs, fc, ruta):
    fig, ax = plt.subplots(2, 1, figsize=(11, 8))
    ax[0].plot(t, x, lw=0.7, alpha=0.6, label="Entrada (cruda)")
    ax[0].plot(t, yf, lw=1.4, label="FIR")
    ax[0].plot(t, yi, lw=1.4, label="IIR")
    ax[0].axvspan(0, n0 / fs, color="gray", alpha=0.2, label="Transitorio descartado")
    lo, hi = float(np.min(x[n0:])), float(np.max(x[n0:]))
    pad = 0.15 * (hi - lo)
    ax[0].set_ylim(lo - pad, hi + pad)               # escala del régimen (el transitorio queda recortado)
    ax[0].set_title(f"{nombre} - {DESCRIPCION[nombre]}: dominio del tiempo")
    ax[0].set_xlabel("Tiempo [s]")
    ax[0].set_ylabel("Aceleración [g]")
    ax[0].legend(loc="best")
    ax[0].grid(True)
    nper = min(512, len(x) - n0)
    for y, etiqueta in ((x, "Entrada"), (yf, "FIR"), (yi, "IIR")):
        f, P = welch(y[n0:], fs, nperseg=nper)            # detrend constante: quita la gravedad
        ax[1].plot(f, 10 * np.log10(P + 1e-20), label=etiqueta)
    ax[1].axvline(fc, color="k", ls="--", lw=0.8, label=f"fc = {fc:g} Hz")
    ax[1].set_title("Espectro (PSD de Welch, sin la componente media)")
    ax[1].set_xlabel("Frecuencia [Hz]")
    ax[1].set_ylabel("PSD [dB (g²/Hz)]")
    ax[1].legend()
    ax[1].grid(True)
    fig.tight_layout()
    fig.savefig(ruta, dpi=150)
    return fig


def fig_barras(df, ruta):
    idx = np.arange(len(df))
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
    ancho = 0.27
    ax[0].bar(idx - ancho, df["SNR_in_dB"], ancho, label="Entrada")
    ax[0].bar(idx, df["SNR_FIR_dB"], ancho, label="FIR")
    ax[0].bar(idx + ancho, df["SNR_IIR_dB"], ancho, label="IIR")
    ax[0].set_title("SNR [dB]")
    ax[1].bar(idx - ancho / 2, df["dSNR_FIR_dB"], ancho, label="FIR")
    ax[1].bar(idx + ancho / 2, df["dSNR_IIR_dB"], ancho, label="IIR")
    ax[1].set_title("ΔSNR [dB]")
    for a_ in ax:
        a_.set_xticks(idx)
        a_.set_xticklabels(df["registro"])
        a_.legend()
        a_.grid(True, axis="y")
    fig.tight_layout()
    fig.savefig(ruta, dpi=150)
    return fig


# ------------------------------ Documento de diseño ---------------------------------
def escribir_diseno(ruta, h, b, a, fs, fc):
    p = np.roots(a)
    wc = 2 * fs * np.tan(np.pi * fc / fs)
    L = [f"DISEÑO DE LOS FILTROS  (fs = {fs:.4f} Hz, fc = {fc:g} Hz, ambos filtros con el mismo corte)", ""]
    L += [f"FIR por ventana (Hamming), orden {len(h) - 1} ({len(h)} coeficientes), scipy.signal.firwin",
          f"  Ecuación en diferencias:  y[n] = sum_(k=0..{len(h) - 1}) h[k] x[n-k]",
          f"  Función de transferencia: H(z) = sum_(k=0..{len(h) - 1}) h[k] z^-k   (denominador = 1: sin realimentación)",
          "  Coeficientes h[k]:"]
    L += [f"    h[{k:2d}] = {v: .10f}" for k, v in enumerate(h)]
    L += [f"  Simetría h[k] = h[{len(h) - 1}-k]: {np.allclose(h, h[::-1])}  -> fase lineal, retardo = {len(h) - 1}/2 = "
          f"{(len(h) - 1) / 2:g} muestras = {(len(h) - 1) / 2 / fs * 1e3:.1f} ms",
          f"  Ganancia en DC = {h.sum():.6f}  (conserva el valor medio)", ""]
    L += [f"IIR Butterworth pasa-bajas, orden {len(a) - 1}, scipy.signal.butter (bilineal con prewarping)",
          "  Prototipo analógico: |H(jΩ)|² = 1 / (1 + (Ω/Ωc)^(2N)),  N = " + str(len(a) - 1),
          f"  Ωc = 2 fs tan(π fc / fs) = {wc:.6f} rad/s  (pre-distorsión de la bilineal s = 2 fs (1 - z^-1)/(1 + z^-1))"]
    num = " + ".join(f"({b[k]:.10g}) z^-{k}" for k in range(len(b)))
    den = " + ".join(["1"] + [f"({a[k]:.10g}) z^-{k}" for k in range(1, len(a))])
    L += [f"  H(z) = [{num}] / [{den}]"]
    tb = " + ".join(f"({b[k]:.10g}) x[n-{k}]" for k in range(len(b)))
    ta = " - ".join(f"({a[k]:.10g}) y[n-{k}]" for k in range(1, len(a)))
    L += [f"  Ecuación en diferencias:  y[n] = {tb} - {ta}",
          "  Coeficientes:"]
    L += [f"    b[{k}] = {v: .12f}" for k, v in enumerate(b)]
    L += [f"    a[{k}] = {v: .12f}" for k, v in enumerate(a)]
    L += ["  Polos de H(z) (raíces de A(z)):"]
    L += [f"    p = {z.real:+.8f} {z.imag:+.8f}j   |p| = {abs(z):.8f}   ángulo = {np.degrees(np.angle(z)):+.3f}°"
          for z in p]
    L += [f"  max|p| = {np.max(np.abs(p)):.6f} < 1  ->  {'ESTABLE' if np.all(np.abs(p) < 1) else 'INESTABLE'}",
          f"  Ganancia en DC = {b.sum() / a.sum():.6f}", ""]
    Path(ruta).write_text("\n".join(L), encoding="utf-8")


# ---------------------------------- Comando ----------------------------------------
def cmd_analizar(args):
    carpeta = Path(args.carpeta)
    fc, of, oi = args.fc, args.orden_fir, args.orden_iir
    salida = carpeta / f"resultados_fc{fc:g}_fir{of}_iir{oi}"
    salida.mkdir(parents=True, exist_ok=True)

    datos = {}
    for r in REGISTROS:
        ruta = carpeta / f"{r}.csv"
        if not ruta.exists():
            sys.exit(f"Falta {ruta}. Captura primero (modo 'capturar') o copia los CSV a la carpeta.")
        datos[r] = leer_registro(ruta)

    fs_regs = [d["fs"] for d in datos.values()]
    fs = float(np.median(fs_regs))
    if (max(fs_regs) - min(fs_regs)) / fs > 0.01:
        print("! Aviso: la fs observada difiere más de 1 % entre registros:", [f"{f:.2f}" for f in fs_regs])
    if fc >= fs / 2:
        sys.exit(f"fc ({fc} Hz) debe ser menor que fs/2 ({fs / 2:.1f} Hz).")
    n0 = int(round(DESCARTE_S * fs))

    print(f"\nfs = {fs:.3f} Hz | fc = {fc:g} Hz | FIR orden {of} | IIR Butterworth orden {oi} | "
          f"se descartan {n0} muestras ({DESCARTE_S:g} s) de cada salida")
    for r, d in datos.items():
        dur = d["t"][-1] - d["t"][0]
        aviso = "" if abs(d["x"].mean()) > 0.8 else "   <-- ¡el eje no parece alineado con la gravedad!"
        print(f"  {r}: {len(d['x'])} muestras, {dur:.2f} s, fs {d['fs']:.2f} Hz, "
              f"jitter {d['jitter_ms']:.2f} ms, media {d['x'].mean():+.4f} g{aviso}")
        if dur < 19.5:
            print(f"  ! {r} dura menos de 20 s.")

    h, b, a = disenar_filtros(fs, fc, of, oi)
    escribir_diseno(salida / "diseno_filtros.txt", h, b, a, fs, fc)
    est_fir, pmax_fir = estabilidad([1.0])
    est_iir, pmax_iir = estabilidad(a)

    # Retardos (no dependen del registro)
    d_teo = {"FIR": retardo_teorico_muestras(h, [1.0], fs, fc), "IIR": retardo_teorico_muestras(b, a, fs, fc)}
    d_obs = {"FIR": retardo_observado_muestras(h, [1.0]), "IIR": retardo_observado_muestras(b, a)}

    filas_snr, filas_fil, señales = [], [], {}
    for r, d in datos.items():
        fila, yf, yi = procesar_registro(r, d, h, b, a, fs, n0)
        filas_snr.append(fila)
        señales[r] = (yf, yi)
        for nombre, num, den, orden, (est, pmax) in (
                ("FIR", h, [1.0], of, (est_fir, pmax_fir)), ("IIR", b, a, oi, (est_iir, pmax_iir))):
            filas_fil.append({
                "registro": r, "filtro": nombre, "orden": orden,
                "retardo_teo_muestras": d_teo[nombre], "retardo_teo_ms": d_teo[nombre] / fs * 1e3,
                "retardo_obs_muestras": d_obs[nombre], "retardo_obs_ms": d_obs[nombre] / fs * 1e3,
                "tiempo_us": tiempo_ejecucion_us(num, den, d["x"]),
                "estable": "sí" if est else "NO", "max_|polo|": pmax,
            })

    df_snr = pd.DataFrame(filas_snr)
    df_fil = pd.DataFrame(filas_fil)
    df_snr.to_csv(salida / "tabla_snr.csv", index=False, float_format="%.6g")
    df_fil.to_csv(salida / "tabla_filtros.csv", index=False, float_format="%.6g")

    pd.set_option("display.width", 220)
    pd.set_option("display.max_columns", 30)
    print("\n=== SNR (dB) y conservación del valor medio (gravedad) ===")
    print(df_snr.to_string(index=False, float_format=lambda v: f"{v:.5g}"))
    print("\n=== Criterios secundarios ===")
    print(df_fil.to_string(index=False, float_format=lambda v: f"{v:.4g}"))
    print("\nNota: 'tiempo_us' es el tiempo de lfilter sobre el MISMO registro en este PC "
          "(sirve para comparar FIR vs IIR, no equivale al tiempo en el ESP32).")

    # Figuras
    figs = [fig_respuesta(h, b, a, fs, fc, salida / "fig_respuesta_frecuencia.png"),
            fig_polos_ceros(h, b, a, salida / "fig_polos_ceros.png"),
            fig_barras(df_snr, salida / "fig_snr_barras.png")]
    for r, d in datos.items():
        yf, yi = señales[r]
        figs.append(fig_registro(r, d["t"], d["x"], yf, yi, n0, fs, fc, salida / f"fig_{r}.png"))
    print(f"\nResultados, figuras y diseño guardados en: {salida.resolve()}")
    if args.mostrar:
        plt.show()
    else:
        for f in figs:
            plt.close(f)


# ------------------------------------ main -----------------------------------------
def main():
    ap = argparse.ArgumentParser(description="PDS Proyecto 2: SNR de una IMU con filtros FIR e IIR")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("puertos", help="lista los puertos serie")
    sp.set_defaults(fn=cmd_puertos)

    sm = sub.add_parser("motor", help="prueba el motor (sin capturar datos)")
    sm.add_argument("--puerto", help="p. ej. COM5 o /dev/ttyUSB0 (si se omite, usa el primero)")
    sm.add_argument("--pwm", type=int, default=100, help="PWM %% (0-100, default 100)")
    sm.add_argument("--segundos", type=float, default=5.0, help="tiempo encendido (default 5 s)")
    sm.set_defaults(fn=cmd_motor)

    sc = sub.add_parser("capturar", help="captura R1, R2 y R3 desde el ESP32")
    sc.add_argument("--puerto", help="p. ej. COM5 o /dev/ttyUSB0 (si se omite, usa el primero)")
    sc.add_argument("--carpeta", default="datos")
    sc.add_argument("--pwm-bajo", type=int, default=30, help="PWM %% de R2 (default 30)")
    sc.add_argument("--pwm-alto", type=int, default=80, help="PWM %% de R3 (default 80)")
    sc.add_argument("--eje", choices=["auto", "x", "y", "z"], default="auto",
                    help="eje alineado con la gravedad (auto = el de mayor |media| en R1)")
    sc.add_argument("--solo", nargs="+", choices=REGISTROS, help="repetir sólo estos registros")
    sc.set_defaults(fn=cmd_capturar)

    sa = sub.add_parser("analizar", help="calcula SNR y aplica FIR/IIR a R1-R3")
    sa.add_argument("--carpeta", default="datos")
    sa.add_argument("--fc", type=float, default=FC_HZ, help="corte común [Hz] (default 5)")
    sa.add_argument("--orden-fir", type=int, default=ORDEN_FIR)
    sa.add_argument("--orden-iir", type=int, default=ORDEN_IIR)
    sa.add_argument("--mostrar", action="store_true", help="abre las figuras en pantalla")
    sa.set_defaults(fn=cmd_analizar)

    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
