
#include <Arduino.h>
#include <Wire.h>

#ifndef ESP_ARDUINO_VERSION_MAJOR
#define ESP_ARDUINO_VERSION_MAJOR 2        // core 2.x no siempre define la macro
#endif

// ----------------------------- Configuración -----------------------------
#define PIN_SDA        21
#define PIN_SCL        22
#define MPU_ADDR       0x68
#define BAUDIOS        115200
#define I2C_HZ         100000          // 100 kHz: mas inmune al ruido del motor
#define I2C_TIMEOUT_MS 5               // una lectura bloqueada no debe alargar la captura

#define FS_HZ          100                 // frecuencia de muestreo
#define DURACION_S     20                  // duración de cada registro
#define N_MUESTRAS     (FS_HZ * DURACION_S)
#define WARMUP_MS      2000                // tiempo para que el motor llegue a régimen

#define PIN_ENA        25          // PWM -> ENA del puente H (quitar el jumper de ENA en el L298N)
#define PIN_IN1        26          // sentido de giro fijo: IN1 = 1, IN2 = 0
#define PIN_IN2        27
#define PWM_FREQ_HZ    5000
#define PWM_BITS       8
#define PWM_CANAL      0                   // sólo se usa con el core 2.x

// Registros del MPU
#define REG_SMPLRT_DIV   0x19
#define REG_CONFIG       0x1A
#define REG_ACCEL_CONFIG 0x1C
#define REG_ACCEL_XOUT_H 0x3B
#define REG_PWR_MGMT_1   0x6B
#define REG_WHO_AM_I     0x75

#define RANGO_G          2                 // ±2 g  ->  16384 LSB/g
#define LSB_POR_G        16384

struct Muestra {
  uint32_t t_us;
  int16_t ax, ay, az;
};
static Muestra buf[N_MUESTRAS];            // 2000 * 12 B = 24 kB

static bool mpuOk = false;
static uint8_t whoAmI = 0;

bool escribirReg(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(val);
  return Wire.endTransmission() == 0;
}

bool leerReg(uint8_t reg, uint8_t &val) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((uint8_t)MPU_ADDR, (uint8_t)1) != 1) return false;
  val = Wire.read();
  return true;
}

bool mpuInit() {
  if (!leerReg(REG_WHO_AM_I, whoAmI)) return false;
  escribirReg(REG_PWR_MGMT_1, 0x80);       
  delay(100);
  escribirReg(REG_PWR_MGMT_1, 0x01);       
  delay(100);
  escribirReg(REG_CONFIG, 0x00);           
  escribirReg(REG_SMPLRT_DIV, 0x00);
  escribirReg(REG_ACCEL_CONFIG, 0x00);     
  delay(50);
  return true;
}

bool leerAccel(int16_t &ax, int16_t &ay, int16_t &az) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(REG_ACCEL_XOUT_H);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((uint8_t)MPU_ADDR, (uint8_t)6) != 6) return false;
  uint8_t d[6];
  for (int i = 0; i < 6; i++) d[i] = Wire.read();   
  ax = (int16_t)((d[0] << 8) | d[1]);
  ay = (int16_t)((d[2] << 8) | d[3]);
  az = (int16_t)((d[4] << 8) | d[5]);
  return true;
}

void i2cIniciar() {
  pinMode(PIN_SDA, INPUT_PULLUP);       
  pinMode(PIN_SCL, INPUT_PULLUP);
  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.setClock(I2C_HZ);
  Wire.setTimeOut(I2C_TIMEOUT_MS);
}

void i2cRecuperar() {
  Wire.end();
  pinMode(PIN_SDA, INPUT_PULLUP);
  pinMode(PIN_SCL, OUTPUT);
  for (int i = 0; i < 9; i++) {            
    digitalWrite(PIN_SCL, HIGH);
    delayMicroseconds(5);
    digitalWrite(PIN_SCL, LOW);
    delayMicroseconds(5);
  }
  digitalWrite(PIN_SCL, HIGH);
  i2cIniciar();
  escribirReg(REG_PWR_MGMT_1, 0x01);      
  escribirReg(REG_CONFIG, 0x00);
  escribirReg(REG_ACCEL_CONFIG, 0x00);
}

void motorSet(int pct) {
  pct = constrain(pct, 0, 100);
  uint32_t duty = ((uint32_t)pct * ((1u << PWM_BITS) - 1)) / 100;
  if (pct == 0) {                          
    digitalWrite(PIN_IN1, LOW);
    digitalWrite(PIN_IN2, LOW);
  } else {                                 
    digitalWrite(PIN_IN1, HIGH);
    digitalWrite(PIN_IN2, LOW);
  }
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(PIN_ENA, duty);
#else
  ledcWrite(PWM_CANAL, duty);
#endif
}

void motorInit() {
  pinMode(PIN_IN1, OUTPUT);
  pinMode(PIN_IN2, OUTPUT);
  digitalWrite(PIN_IN1, LOW);
  digitalWrite(PIN_IN2, LOW);
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(PIN_ENA, PWM_FREQ_HZ, PWM_BITS);
#else
  ledcSetup(PWM_CANAL, PWM_FREQ_HZ, PWM_BITS);
  ledcAttachPin(PIN_ENA, PWM_CANAL);
#endif
  motorSet(0);
}

void capturar(const char *cond, int pwm) {
  if (!mpuOk) {
    Serial.println("ERR MPU no responde (revisa SDA/SCL/alimentacion)");
    return;
  }
  motorSet(pwm);
  if (pwm > 0) delay(WARMUP_MS);

  const uint32_t T_us = 1000000UL / FS_HZ;
  uint32_t errores = 0;
  uint8_t fallosSeguidos = 0;
  int16_t ax = 0, ay = 0, az = 0;          

  const uint32_t t0 = micros();
  for (uint32_t i = 0; i < N_MUESTRAS; i++) {
    const uint32_t objetivo = i * T_us;
    for (;;) {                              
      int32_t falta = (int32_t)(objetivo - (micros() - t0));
      if (falta <= 0) break;
      if (falta > 2000) delay(1);
      else delayMicroseconds(falta);
    }
    const uint32_t ts = micros() - t0;
    if (!leerAccel(ax, ay, az)) {
      errores++;
      if (++fallosSeguidos >= 3) {         
        i2cRecuperar();
        fallosSeguidos = 0;
      }
    } else {
      fallosSeguidos = 0;
    }
    buf[i].t_us = ts;
    buf[i].ax = ax;
    buf[i].ay = ay;
    buf[i].az = az;
  }
  motorSet(0);

  Serial.printf("# registro=%s\n", cond);
  Serial.println("# imu=MPU6050/6500");
  Serial.printf("# who_am_i=0x%02X\n", whoAmI);
  Serial.printf("# fs_hz=%d\n", FS_HZ);
  Serial.printf("# n=%d\n", N_MUESTRAS);
  Serial.printf("# duracion_s=%d\n", DURACION_S);
  Serial.printf("# rango_g=%d\n", RANGO_G);
  Serial.printf("# lsb_por_g=%d\n", LSB_POR_G);
  Serial.printf("# pwm_pct=%d\n", pwm);
  Serial.printf("# i2c_errores=%lu\n", (unsigned long)errores);
  for (uint32_t i = 0; i < N_MUESTRAS; i++) {
    Serial.printf("D,%lu,%d,%d,%d\n", (unsigned long)buf[i].t_us, buf[i].ax, buf[i].ay, buf[i].az);
  }
  Serial.println("END");
}

void procesarLinea(String l) {
  l.trim();
  if (l.length() == 0) return;

  if (l == "PING") {
    Serial.println("OK PDS-IMU v3 (puente H: ENA=25 IN1=26 IN2=27)");
  } else if (l.startsWith("START")) {
    char cond[16] = "R?";
    int pwm = 0;
    int n = sscanf(l.c_str(), "START %15s %d", cond, &pwm);
    if (n < 1) {
      Serial.println("ERR formato: START <R1|R2|R3> <pwm_pct>");
      return;
    }
    capturar(cond, pwm);
  } else if (l.startsWith("MOTOR")) {
    int pwm = 0;
    if (sscanf(l.c_str(), "MOTOR %d", &pwm) == 1) {
      motorSet(pwm);
      Serial.printf("OK motor %d%%\n", constrain(pwm, 0, 100));
    } else {
      Serial.println("ERR formato: MOTOR <pwm_pct>");
    }
  } else if (l == "STOP") {
    motorSet(0);
    Serial.println("OK stop");
  } else {
    Serial.println("ERR comando desconocido");
  }
}

void setup() {
  Serial.begin(BAUDIOS);
  motorInit();
  i2cIniciar();
  delay(200);
  mpuOk = mpuInit();
  Serial.println("# FW v3: puente H ENA=25 IN1=26 IN2=27, I2C 100 kHz con recuperacion");
  Serial.println(mpuOk ? "# MPU listo" : "# ERR MPU no detectado");
}

void loop() {
  static String linea;
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\n') {
      procesarLinea(linea);
      linea = "";
    } else if (c != '\r') {
      linea += c;
    }
  }
}